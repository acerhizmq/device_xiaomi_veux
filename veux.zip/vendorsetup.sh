if [ ! -d "vendor/xiaomi/veux" ]; then
    git clone https://github.com/Project-Astraverse/vendor_xiaomi_veux.git vendor/xiaomi/veux
fi

if [ ! -d "kernel/xiaomi/sm6375" ]; then
    git clone https://github.com/Starrykernel/kernel_xiaomi_veux.git -b 16-Q2-KSU kernel/xiaomi/sm6375 --depth=1
fi

if [ ! -d "hardware/xiaomi" ]; then
    git clone https://github.com/LineageOS/android_hardware_xiaomi.git hardware/xiaomi
fi

# Viper4Android
if [ ! -d "packages/apps/ViPER4AndroidFX" ]; then
    git clone https://github.com/AxionAOSP/android_packages_apps_ViPER4AndroidFX.git -b v4a packages/apps/ViPER4AndroidFX
fi

# MiuiCamera (Disabled for Leica variant)
# if [ ! -d "vendor/xiaomi/miuicamera-veux" ]; then
#     git clone https://github.com/frost-testzone/vendor_xiaomi_miuicamera-veux.git vendor/xiaomi/miuicamera-veux
# fi

# Leica Camera Integration
#if [ ! -d "vendor/xiaomi/camera" ]; then
#    git clone https://gitlab.com/isaiahscape/vendor_xiaomi_camera.git vendor/xiaomi/camera
#fi

# Dolby
if [ ! -d "hardware/dolby" ]; then
    git clone https://github.com/oscaro-resources/hardware_dolby.git hardware/dolby
fi
