#include <fstream>
#include <string>

static const std::string kTorchLedPath = "/sys/class/leds/led:torch_0";
static const std::string kTorchLed1Path = "/sys/class/leds/led:torch_1";

template <typename T>
static void set(const std::string& path, const T& value) {
    std::ofstream file(path);
    if (file.is_open()) {
        file << value;
    }
}

template <typename T>
static T get(const std::string& path, const T& def) {
    std::ifstream file(path);
    T result;
    file >> result;
    return file.fail() ? def : result;
}

extern "C" {

bool supportsTorchStrengthControlExt() {
    return true;
}

bool supportsSetTorchModeExt() {
    return true;
}

int32_t getTorchDefaultStrengthLevelExt() {
    return 100; // Default brightness level out of 255
}

int32_t getTorchMaxStrengthLevelExt() {
    auto node = kTorchLedPath + "/max_brightness";
    int32_t max = get(node, 0);
    return max <= 0 ? 255 : max;
}

int32_t getTorchStrengthLevelExt() {
    auto node = kTorchLedPath + "/brightness";
    return get(node, 0);
}

void setTorchStrengthLevelExt(int32_t torchStrength) {
    // Write strength to torch_0 and torch_1 for dual-LED
    set(kTorchLedPath + "/brightness", torchStrength);
    set(kTorchLed1Path + "/brightness", torchStrength);
    
    // Some Xiaomi devices require switch toggles to activate the MOSFETs
    set("/sys/class/leds/led:switch_0/brightness", torchStrength > 0 ? 255 : 0);
    set("/sys/class/leds/led:switch_1/brightness", torchStrength > 0 ? 255 : 0);
    set("/sys/class/leds/led:switch_2/brightness", torchStrength > 0 ? 255 : 0);
}

void setTorchModeExt(bool enabled) {
    int32_t strength = getTorchDefaultStrengthLevelExt();
    setTorchStrengthLevelExt(enabled ? strength : 0);
}

} // extern "C"
